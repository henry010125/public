function dfaults() {
    document.getElementById('zero').className = 'btn btn-light selectep';
    document.getElementById('one').className = 'btn btn-light selectep';
    document.getElementById('two').className = 'btn btn-light selectep';
    document.getElementById('three').className = 'btn btn-light selectep';
    document.getElementById('four').className = 'btn btn-light selectep';
    document.getElementById('five').className = 'btn btn-light selectep';
    document.getElementById('six').className = 'btn btn-light selectep';
    document.getElementById('seven').className = 'btn btn-light selectep';
    document.getElementById('eight').className = 'btn btn-light selectep';
    document.getElementById('nine').className = 'btn btn-light selectep';
    document.getElementById('ten').className = 'btn btn-light selectep';
    document.getElementById('eleven').className = 'btn btn-light selectep';
    document.getElementById('twelve').className = 'btn btn-light selectep';
    document.getElementById('thirteen').className = 'btn btn-light selectep';
    document.getElementById('fourteen').className = 'btn btn-light selectep';
}

function _home() {
    document.getElementById('zero').className = 'btn btn-primary selectep';
}

function _video1() {
    document.getElementById('one').className = 'btn btn-primary selectep';
}

function _video2() {
    document.getElementById('two').className = 'btn btn-primary selectep';
}

function _video3() {
    document.getElementById('three').className = 'btn btn-primary selectep';
}

function _video4() {
    document.getElementById('four').className = 'btn btn-primary selectep';
}

function _video5() {
    document.getElementById('five').className = 'btn btn-primary selectep';
}

function _video6() {
    document.getElementById('six').className = 'btn btn-primary selectep';
}

function _video7() {
    document.getElementById('seven').className = 'btn btn-primary selectep';
}

function _video8() {
    document.getElementById('eight').className = 'btn btn-primary selectep';
}

function _video9() {
    document.getElementById('nine').className = 'btn btn-primary selectep';
}

function _video10() {
    document.getElementById('ten').className = 'btn btn-primary selectep';
}

function _video11() {
    document.getElementById('eleven').className = 'btn btn-primary selectep';
}

function _video12() {
    document.getElementById('twelve').className = 'btn btn-primary selectep';
}

function _video13() {
    document.getElementById('thirteen').className = 'btn btn-primary selectep';
}

function _video14() {
    document.getElementById('fourteen').className = 'btn btn-primary selectep';
}