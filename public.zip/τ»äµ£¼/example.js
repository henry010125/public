function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1hiXuOMbKvJPZyPT2t6XPdMyU-YzPP6Qf?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function dfaults() {
    document.getElementById('zero').className = 'btn btn-light selectep';
    document.getElementById('one').className = 'btn btn-light selectep';
    document.getElementById('two').className = 'btn btn-light selectep';
    document.getElementById('three').className = 'btn btn-light selectep';
    document.getElementById('four').className = 'btn btn-light selectep';
    document.getElementById('five').className = 'btn btn-light selectep';
    document.getElementById('six').className = 'btn btn-light selectep';
    document.getElementById('seven').className = 'btn btn-light selectep';
    document.getElementById('eight').className = 'btn btn-light selectep';
    document.getElementById('nine').className = 'btn btn-light selectep';
    document.getElementById('ten').className = 'btn btn-light selectep';
    document.getElementById('eleven').className = 'btn btn-light selectep';
    document.getElementById('twelve').className = 'btn btn-light selectep';
    document.getElementById('thirteen').className = 'btn btn-light selectep';
}


function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
    document.getElementById('zero').className = 'btn btn-primary selectep';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 可能性的起點';
    document.getElementById('one').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 墓碑迷宮';
    document.getElementById('two').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 超級';
    document.getElementById('three').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 逆轉如翻旗';
    document.getElementById('four').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 地獄門';
    document.getElementById('five').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 小數點的彼方';
    document.getElementById('six').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 決鬥都市';
    document.getElementById('seven').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 超級激戰';
    document.getElementById('eight').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 狂宴的開幕';
    document.getElementById('nine').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 棋盤上的攻防';
    document.getElementById('ten').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 勝利者的右腕';
    document.getElementById('eleven').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 破壞王';
    document.getElementById('twelve').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_12.mp4';
}

function video13() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#13 延續可能性的人們';
    document.getElementById('thirteen').className = 'btn btn-primary selectep';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_13.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/〈Infinite_Dendrogram〉-無盡連鎖-/〈Infinite_Dendrogram〉-無盡連鎖-_1080P_13.mp4';
}