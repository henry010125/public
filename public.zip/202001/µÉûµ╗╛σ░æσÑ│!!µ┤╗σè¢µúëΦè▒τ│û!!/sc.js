function dl() {
    location.href = 'https://www.googleapis.com/drive/v3/files/10Pd3bGl4KvbXD14pOSc6btrATJTgm7Fc?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 旋律-Schlehit Melodie-';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 Plasmaism';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 釋放吧！咚咚咚—！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 心跳!?女～孩子滿載的飄飄然游泳大賽！哦♡走光（以下略';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 Just Awake';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 Cadenza';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 十六夜雪洞唄';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 Re:Climb';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 絆Eternal';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 斷罪的Solitude';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 My Resolution';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 My Song is YOU !!';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/SHOW_BY_ROCK！！活力棉花糖！！/SHOW_BY_ROCK！！活力棉花糖！！_1080P_12.mp4';
}