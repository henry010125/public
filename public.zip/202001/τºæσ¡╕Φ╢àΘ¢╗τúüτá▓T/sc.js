function dl1() {
    location.href='https://www.googleapis.com/drive/v3/files/1fOzFpd0Ti2YMBvVMFviiY1PsZtIl7DEo?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}
function dl2() {
    location.href='https://www.googleapis.com/drive/v3/files/1-RUFnIRbxpQeROdZ9dVaegOmTJoub4fK?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}
function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 超能力者LEVEL5';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_01.mp4';
}
function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 大霸星祭';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_02.mp4';
}
function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 氣球獵人	';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_03.mp4';
}
function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 竄改';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_04.mp4';
}
function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 信賴';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_05.mp4';
}
function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 開戰';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_06.mp4';
}
function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 百聞不如一見 Auribus oculi fideliores sunt.';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_07.mp4';
}
function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 Railgun Mental Out 超電磁砲×心理掌握';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_08.mp4';
}
function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 警策看取';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_09.mp4';
}
function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 才人工房 Clone Dolly';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_10.mp4';
}
function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 參戰';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_11.mp4';
}
function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 外裝代腦 Exterior';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_12.mp4';
}
function video13() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#13 以非神之軀領悟上天意志之人 ＳＹＳＴＥＭ';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_13.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_13.mp4';
}
function video14() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#14 龍王之顎 Dragon Strike';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_14.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_14.mp4';
}
function video15() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#15 約定';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_15.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1/%E7%A7%91%E5%AD%B8%E8%B6%85%E9%9B%BB%E7%A3%81%E7%A0%B2T_P1_1080P_15.mp4';
}
function video16() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#16 Dream Ranker 天賦夢路';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_16.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_16.mp4';
}
function video17() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#17 預知';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_17.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_17.mp4';
}
function video18() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#18 巨乳御手 Bust Upper';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_18.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_18.mp4';
}
function video19() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#19 奇緣';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_19.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_19.mp4';
}
function video20() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#20 Ha det bra';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_20.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_20.mp4';
}
function video21() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#21 Doppelgänger 分身';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_21.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_21.mp4';
}
function video22() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#22 Scavenger 食屍部隊';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_22.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_22.mp4';
}
function video23() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#23 附身';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_23.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_23.mp4';
}
function video24() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#24 擴散';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_24.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_24.mp4';
}
function video25() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#25 我重要的朋友';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_25.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/07/科學超電磁砲T_P2/科學超電磁砲T_P2_1080P_25.mp4';
}