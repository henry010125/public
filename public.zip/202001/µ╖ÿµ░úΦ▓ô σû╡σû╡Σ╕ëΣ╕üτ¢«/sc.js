function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1iW5XZ1XmPUjbx13Mrc76vkoFkQFjKHzC?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 我家的圓圓你知道嗎？|狗狗會議|我們的WAIHA';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 本大爺是布魯|和平|去海邊';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 3丁目最強的男人|3丁目最弱的男人';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 圓圓的工作|吾輩是小黃|狗狗警察';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 小虎的初戀|來泡澡吧|續・狗狗警察';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 無仁義貓狗 上集|無仁義貓狗 下集|夜間野餐';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 圓圓被綁架|嚇一跳|貓咪咖啡廳・Violet';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 祭典之聲';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 那傢伙來到鎮上了|野貓與小貓';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 不可以睡著|3丁目猜謎王|貝貝和布魯〜兩個人是好朋友〜';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 圓圓的真面目|貓貓會議|我最重要的東西';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～/淘氣貓2020：家有圓圓？！～我家的圓圓你知道嗎～_720P_11.mp4';
}