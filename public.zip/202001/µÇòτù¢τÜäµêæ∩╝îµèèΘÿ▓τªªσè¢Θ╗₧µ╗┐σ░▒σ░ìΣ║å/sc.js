function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1dVezrLCaGRyW72uZ80bBz-blcLyBzDmF?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 防禦特化與首戰。';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 防禦特化與朋友。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 防禦特化與攻略第二階地區。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 防禦特化與第二場活動。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 防禦特化與戰利品。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 防禦特化與新戰力。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 防御特化與強化。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 防禦特化與第三場活動。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 目防禦特化與第四場活動。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 防御特化與出擊。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 防御特化與強敵。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 防禦特化與聯繫。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/怕痛的我，把防禦力點滿就對了/怕痛的我，把防禦力點滿就對了_1080P_12.mp4';
}