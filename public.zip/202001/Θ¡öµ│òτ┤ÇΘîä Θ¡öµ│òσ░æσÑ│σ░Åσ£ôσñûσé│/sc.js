function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/12TSryLVLieQ20HEiBM3EclA9zmFRN4rm?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}
function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}
function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 知道嗎？魔法少女的那個傳言';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_01.mp4';
}
function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 絕交的證書';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_02.mp4';
}
function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 抱歉把妳當成朋友';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_03.mp4';
}
function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 這才不是過去呢';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_04.mp4';
}
function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 這裡並沒有妳插手的餘地喔？';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_05.mp4';
}
function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 什麼都願意做喔';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_06.mp4';
}
function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 想和妳一起回去';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_07.mp4';
}
function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 絕對不可以回信喔';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_08.mp4';
}
function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 只有我存在的世界';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_09.mp4';
}
function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 我的名字';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_10.mp4';
}
function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 相約在下午三點的記憶博物館';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_11.mp4';
}
function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 為什麼如此悲慘呢';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_12.mp4';
}
function video13() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#13 唯一的一座路標';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_13.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/魔法紀錄_魔法少女小圓外傳/魔法紀錄_魔法少女小圓外傳_1080P_13.mp4';
}