function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1pag8XXWRwRi_u2wHdGOjpbqqbDMIYWmo?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}
function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 自我介紹';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_01.mp4';
}
function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 迷途';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_02.mp4';
}
function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 視角';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_03.mp4';
}
function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 輕鬆';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_04.mp4';
}
function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 空腹';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_05.mp4';
}
function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 昂揚';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_06.mp4';
}
function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 歸來';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_07.mp4';
}
function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 挑戰者';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_08.mp4';
}
function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 各自的夜晚';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_09.mp4';
}
function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 戰線';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_10.mp4';
}
function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 連繫起來的機會？';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_11.mp4';
}
function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 鮮明';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_12.mp4';
}
function video13() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#13 第二天';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_13.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_13.mp4';
}
function video14() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#14 節奏';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_14.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_14.mp4';
}
function video15() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#15 尋覓';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_15.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_15.mp4';
}
function video16() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#16 失戀';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_16.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_16.mp4';
}
function video17() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#17 貓VS猴子';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_17.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_17.mp4';
}
function video18() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#18 陷阱';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_18.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_18.mp4';
}
function video19() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#19 最強的挑戰者';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_19.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_19.mp4';
}
function video20() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#20 頭';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_20.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_20.mp4';
}
function video21() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#21 英雄';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_21.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_21.mp4';
}
function video22() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#22 岩釘';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_22.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_22.mp4';
}
function video23() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#23 安靜的王之誕生';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_23.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_23.mp4';
}
function video24() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#24 怪物們的宴會';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_24.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_24.mp4';
}
function video25() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#25 約定之地';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_25.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/排球少年！！TO_THE_TOP_S4_P1/排球少年_4th_1080P_25.mp4';
}