function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1wlH1SwQhMgxu6CL05kX_URjEax6nB8o_?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 理科生墜入情網故試分析。';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 理科生墜入情網故試實驗。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 理科生墜入情網故試安排約會。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 理科生墜入情網故試約會。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 理科生墜入情網故試開會。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 理科生墜入情網故試接吻。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 理科生墜入情網故試酒局。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 理科生墜入情網故試收集喜歡的證據。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 理科生墜入情網故試沖繩集訓。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 理科生墜入情網故試發表研究。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 理科生墜入情網故試爭吵。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 試證明你能收獲戀愛。';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/理科生墜入情網，故嘗試證明。/理科生墜入情網，故嘗試證明。_1080P_12.mp4';
}