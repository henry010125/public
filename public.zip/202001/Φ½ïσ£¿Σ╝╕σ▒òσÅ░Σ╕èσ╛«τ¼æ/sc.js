function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/1XJjSGWaJHrsmJi754TjgElLjfMmQMunS?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 這是屬於你的故事';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 職業的世界';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 請在伸展台上微笑';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 年輕有為的人們';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 各自的作風';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 優越感和自卑感';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 Aura 存在感';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 設計師的器量';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 Rival 勁敵';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 不能輸';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 約定';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 這是屬於我的故事';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/請在伸展台上微笑/請在伸展台上微笑_1080P_12.mp4';
}