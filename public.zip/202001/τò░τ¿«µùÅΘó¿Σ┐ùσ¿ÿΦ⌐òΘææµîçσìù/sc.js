function dl() {
    location.href='https://www.googleapis.com/drive/v3/files/162Lvu5-qA21rAHY3fvoIV5bOjAn1-OI8?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}

function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 關於精靈熟女與人類熟女的議論沸騰，天使在喵喵天國升天，有翼人通過總排泄孔的敏感度也效果拔群！';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_01.mp4';
}

function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 妖精有插入之尺寸限制，惡魔族沒有什麼人氣，乳牛系的彌諾陶洛斯又大又會搖爆射不止！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_02.mp4';
}

function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 女體化後能選的小姐不但很少，而且玩起來還挺痛的，但如此一來就能理解女孩子的感覺，所以試著體驗一下或許是個不錯的主意喔！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_03.mp4';
}

function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 低級淫魔就算說已經射不出來了，也還是會不斷榨精根本就是拷問之域。火龍小姐的身和心和火和龍雖然都熱情如火，但是因為實在熱過頭了所以搞到幾乎都快要往生了！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_04.mp4';
}

function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 雖然想沉溺在獨眼女孩閃耀的眼眸中但門檻實在太高了，同樣基於門檻過高的原因所以找蘑菇小姐時就交給幹了好幾百年的老江湖選擇，黏呼呼滑溜溜軟綿綿！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_05.mp4';
}

function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 魔像雖然只要能做出理想中的女孩子就能盡情享受但是很講究品味，而且要是被原型人物發現可能會大事不妙。光精靈的店內有幻想般的光之遊行隊伍，簡直就是夢之樂園';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_06.mp4';
}

function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 產卵秀讓大叔們看得目不轉睛！蛋蛋生出來讓人看光光！梅多莉的秘密！然後終於要發表了！夢魔女郎的人氣投票結果！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_07.mp4';
}

function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 情境夢魔的情色之夢開啟漫漫長夜，天使之槍是不輸給聖槍的性槍，在夢魔之塔美乃滋將爆射永不停止！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_08.mp4';
}

function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 肢體與屍體間有深沉而黑暗的某種東西，年輕天使的潤滑劑大爆發，野生而野性的評鑑者們是色情的勁敵！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_09.mp4';
}

function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 獲得四十分滿分的店家之謎終於即將揭曉！享受新妻加淫亂家教加母豬加戀人的感覺！射出來噴出來進進又出出！無限解放！超滿足的三天時光！白果醬射好射滿！大家一起獲得幸福吧啊啊啊啊！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_10.mp4';
}

function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 讓淫魔們通通高潮的超可怕絕倫男是博愛主義者，賺得不義之財的醉漢下場就如同各位所想像，光惠的房間將在本日完結！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_11.mp4';
}

function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 感謝各位對異種族評鑑者們的厚愛，我們後會有期…。只要有夢魔小姐的存在，相信評鑑者們都將永遠活下去。每當各位想到評鑑者們時一定就會跟著回想起來吧。當人們成功讓其他人高潮時，才會首次感覺到自己也很能幹的事實…';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/異種族風俗娘評鑑指南/異種族風俗娘評鑑指南_1080P_12.mp4';
}