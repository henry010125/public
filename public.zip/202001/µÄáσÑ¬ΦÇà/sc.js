function dl1() {
    location.href='https://www.googleapis.com/drive/v3/files/1Pgs-7HXmatd9AWOOemMDU1FWwNeoSsYi?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}
function dl2() {
    location.href='https://www.googleapis.com/drive/v3/files/1Hme_gcwimUbghF5lwnvpf3ceulDPaqx5?supportsAllDrives=true&supportsTeamDrives=true&key=AIzaSyCFXD7hsqD_zXh6Zt3Zd1bAHsJap3mvLvQ&alt=media'
}

function home() {
    document.getElementById('home').style.display = 'unset';
    document.getElementById('video').style.display = 'none';
    document.getElementById('Episode').innerHTML = '故事大綱';
}
function video1() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#01 傳說中的擊墜王';    
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_01.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_01.mp4';
}
function video2() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#02 我恨你！';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_02.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_02.mp4';
}
function video3() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#03 這是制服 沒辦法	';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_03.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_03.mp4';
}
function video4() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#04 違法持有者';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_04.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_04.mp4';
}
function video5() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#05 別道歉 道歉啊';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_05.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_05.mp4';
}
function video6() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#06 直覺';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_06.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_06.mp4';
}
function video7() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#07 很美味';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_07.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_07.mp4';
}
function video8() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#08 阿比斯惡魔';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_08.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_08.mp4';
}
function video9() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#09 掠奪者';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_09.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_09.mp4';
}
function video10() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#10 認真';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_10.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_10.mp4';
}
function video11() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#11 珍藏';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_11.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_11.mp4';
}
function video12() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#12 入學儀式';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_12.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_12.mp4';
}
function video13() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#13 肚子很飽';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_13.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_13.mp4';
}
function video14() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#14 7分12秒';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_14.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_14.mp4';
}
function video15() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#15 不殺人軍隊';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_15.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_15.mp4';
}
function video16() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#16 廢棄戰爭';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_16.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_16.mp4';
}
function video17() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#17 閃擊的擊墜王';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_17.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_17.mp4';
}
function video18() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#18 艾爾西亞的誕生';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_18.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_18.mp4';
}
function video19() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#19 花心';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_19.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_19.mp4';
}
function video20() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#20 雨';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_20.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_20.mp4';
}
function video21() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#21 父親';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_21.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_21.mp4';
}
function video22() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#22 約定';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_22.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_22.mp4';
}
function video23() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#23 饒不了你';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_23.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_23.mp4';
}
function video24() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('video').style.display = 'unset';
    document.getElementById('Episode').innerHTML = '#24 我的撃墜王';
    document.getElementById('1080P').src = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_24.mp4';
    document.getElementById('download').href = 'https://animeserver.azurewebsites.net/AnimeServer_backup_A/2020/01/掠奪者/掠奪者_1080P_24.mp4';
}